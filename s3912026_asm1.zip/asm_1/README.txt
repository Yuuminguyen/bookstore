This is my sample static website about my cv
It is including Home, CV, Projects, Blogs, Contact
link to visit my website: 
http://rmit-asm-1.surge.sh/

cite: 
King, J. (2022, January 13). Cats Notebooks. Pinterest. Retrieved July 23, 2022, from https://www.pinterest.com/pin/1126533294264059056/
No0b, G. (2020, October 23). Crimson Agate map location genshin impact. Pinterest. Retrieved July 23, 2022, from https://pin.it/1vSk1IV
Groove Technology. (2021, May 18). Top 9 mobile app UX/UI design trends in 2021. Youtube. Retrieved July 23, 2022, from https://www.youtube.com/watch?v=0Yyn-IPVtDU